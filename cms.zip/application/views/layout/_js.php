<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
	integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
	integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
	integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous">
</script>
<script src="<?= base_url('assets/Admin/')?>plugins/chart.min.js"></script>
<!-- Icons library -->
<script src="<?= base_url('assets/Admin/')?>plugins/feather.min.js"></script>
<!-- Custom scripts -->
<script src="<?= base_url('assets/Admin/')?>js/script.js"></script>
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url('assets/Public/')?>lib/wow/wow.min.js"></script>
<script src="<?= base_url('assets/Public/')?>lib/easing/easing.min.js"></script>
<script src="<?= base_url('assets/Public/')?>lib/waypoints/waypoints.min.js"></script>
<script src="<?= base_url('assets/Public/')?>lib/counterup/counterup.min.js"></script>
<script src="<?= base_url('assets/Public/')?>lib/owlcarousel/owl.carousel.min.js"></script>

<!-- Template Javascript -->
<script src="<?= base_url('assets/Public/')?>js/main.js"></script>
<script src="https://code.jquery.com/jquery-3.1.0.js"></script>
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script>
	$(document).ready(function () {
		$('#tabel-data').DataTable();
	});

</script>
<script>
	$('#ngilang').delay('slow').slideDown('slow').delay(4000).slideUp(600);

</script>
