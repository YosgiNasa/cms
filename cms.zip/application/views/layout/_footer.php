<footer class="footer">
    <div class="container footer--flex">
        <div class="footer-start">
            <p>2023 © _nasadel
            </p>
        </div>
    </div>
</footer>