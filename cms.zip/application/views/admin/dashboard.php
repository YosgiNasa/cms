<marquee>
	<h1>Selamat Datang Di Halaman Dashboard,<?= $this->session->userdata('nama') ?></h1>
</marquee>

